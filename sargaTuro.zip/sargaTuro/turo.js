function receptModositas() {
    let szemelyekSzama = document.getElementById("szemelyek").value;
    if(szemelyekSzama<1){document.getElementById("szemelyek").value=1;
    szemelyekSzama = 1;}
    
    let elem = document.getElementById("lista");
    let elemek = elem.getElementsByTagName("li");
    let tej = elemek[0].textContent;
    let tojas = elemek[1].textContent;
    let cukor = elemek[2].textContent;
    let tejIndex = tej.indexOf(" ");
    let cukorIndex = cukor.indexOf(" ");
    let tojasIndex = tojas.indexOf(" ");
    let tejKell = 0.2 * szemelyekSzama;
    let tojasKell = 2 * szemelyekSzama;
    let cukorKell = szemelyekSzama;

    elemek[0].innerHTML = tejKell + tej.slice(tejIndex);
    elemek[1].innerHTML = tojasKell + tojas.slice(tojasIndex);
    elemek[2].innerHTML = cukorKell + cukor.slice(cukorIndex);
    
}

document.getElementById("szemelyek").addEventListener("change", receptModositas);


