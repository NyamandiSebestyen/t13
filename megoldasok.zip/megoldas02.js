/*
Készíts egy olyan programot, mely bekér egy számot és a hatványozás mértékét, és kiírja annak
hatványát. pl.: 2 és 3, azaz kettő a harmadikon, azaz az eredmény 8 lesz!
*/

let x = prompt("Adj meg egy számot!");
let y = prompt("Add meg, hogy a szám hanyadik hatványára vagy kíváncsi!");
document.write(Math.pow(x,y));