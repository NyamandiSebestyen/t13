/*
Készíts egy programot, ami bekér egy életkort 1-120 között és ennek függvényében megjeleníti az
illető besorolását. 120 kor felett vagy 0 alatt, pedig hibát kapjunk!
• Kisgyermekkor: 0-6 év
• Gyermekkor: 6-12 év
• Serdülőkor: 12-16 év
• Ifjúkor: 16-20 év
• Fiatal felnőtt kor: 20-30 év
• Felnőtt kor: 30-60
• Aggkor: 60-tól
*/
let x = prompt("Add meg az életkorod!");
if(x<0 || x >120 || isNaN(x)){
    document.write(`Hibás bemenet!`);
}else if(x>0 && x<7){
    document.write(`Kisgyermekkor`);
}else if(x>7 && x<12){
    document.write(`Gyermekkor`);
}else if(x>12 && x<16){
    document.write(`Serdülőkor`);
}else if(x>16 && x<20){
    document.write(`Ifjúkor`);
}else if(x>20 && x<30){
    document.write(`Fiatal felnőtt kor`);
}else if(x>30 && x<60){
    document.write(`Felnőtt kor`);
}else {
    document.write(`Aggkor`);
}