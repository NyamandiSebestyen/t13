/*
Készíts egy programot, ami egy adott intervallumban generál ki páros számot, és írja ki az értékét, a
határétéket te magad állíthatod be, bekérés, alapján.
*/
let min = prompt("Add meg az intervallum alsó határát!");
let max = prompt("Add meg az intervallum felső határát!");
document.write(`A radnom generált szám: ${Math.floor(Math.random()*(Math.floor(max/2)-min)+min)*2}`);