/*
Készíts egy olyan kódot mely kiírja az adott file készítőjének
• Nevét
• Csoportjának azonosítóját (melyik #Team tagja)
• 3.-4. és 5. sor pedig az legyen, mennyire érti a HTML, CSS és jelenlegi JavaScript
tananyagokat 1-100-ig (pl.: html: 90)
*/
document.write(`Nyámándi Sebestyén<br>#TEAM13<br>HTTML: 100<br>CSS: 98<br>JavaScript: 100<br>`);

