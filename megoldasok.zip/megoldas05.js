/*
Készíts egy olyan kódot, mely paraméterként bekér egy számot és egy osztót és kiírja szövegesen,
hogy az adott osztó, osztja-e az egész számot, úgy, hogy a maradék nulla.
*/
let x = prompt("Adj meg egy számot!");
let y = prompt("Adj meg egy osztót!");
let z = "";
if(x%y!=0){
 z = "nem"}
document.write(`A megadott osztó ${z} tudja osztani a számot maradék nélkül.`);